import java.util.Arrays;

public class methodSumsandalotMore {

	public static void main(String[] args) {

		 System.out.println("least: "+sumClass.least(123,456,3546));
		 System.out.println("greatest: "+sumClass.greatest(385,1,444));
		 System.out.println("sum: "+sumClass.sum(385,444,444));
	
		 
		 
		 
		 
		 
		 safeexampleClass mysafeexampleClass = new safeexampleClass( );
		 
		 
		 int b[]= mysafeexampleClass.getSecrectNumbers();
		 
		 System.out.println(Arrays.toString(b));
		 
		 int a[]={9,9,9};
		 mysafeexampleClass.setSecrectNumbers(a);
		
		  b= mysafeexampleClass.getSecrectNumbers();
		 
		 
		 
	
		 System.out.println(Arrays.toString(b));

	}

	
	
	
	
	
	
}