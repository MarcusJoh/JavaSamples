public class safeexampleClass {
	 private int secrectNumbers[] = { 1, 2, 3 };

		public int[] getSecrectNumbers() {
			return secrectNumbers;
		}

		public void setSecrectNumbers(int secrectNumbers[]) {
			this.secrectNumbers = secrectNumbers;
		}


}